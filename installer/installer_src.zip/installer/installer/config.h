
#define PRODUCT_VERSION   L"1.2.3"

#define DISPLAY_NAME L"Install product Test Display" PRODUCT_VERSION
#define PRODUCT_NAME L"Install product Test"

#define PRODUCT_PUBLISHER L"Install Test Company"
#define PRODUCT_WEB_SITE L"https://YOURSITE/"

//YOUR PRODUCT ID
#define PRODUCT_CODE L"{A9E770C4-FCF1-4E52-A3B4-44D394886A3A}"


#define FILES\
    {"release/uninstall.exe", "uninstall.exe" }



