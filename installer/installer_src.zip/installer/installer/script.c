/*
     THIS IS THE CUSTOMIZATION FILE
*/

#include "installer_.h"
#include "config.h"


void OnFilesExtracted()
{
  /*
    This function is called after all files and common registry keys
    were writtem    
  */

}