#pragma once
#include <windows.h>
#include "resource.h"

# //BEGIN_EXPORT
void SystemCreateProcess(const WCHAR* moduleName, const WCHAR* cmdline);
# //END_EXPORT
