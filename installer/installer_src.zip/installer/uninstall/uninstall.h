#pragma once
#include <windows.h>
#include "resource.h"
